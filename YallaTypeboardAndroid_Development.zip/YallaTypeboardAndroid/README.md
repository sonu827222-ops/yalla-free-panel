# Yalla Typeboard Android — source project

This is an Android Studio Kotlin project for a movable floating companion panel inspired by the supplied reference video.

## Included
- Floating overlay window (requires Android's “Display over other apps” permission)
- Auto Nums, Auto Alpha, Auto Words and iPhone Drop switches
- Prepare text and copy to clipboard
- Draggable panel and close button

## Build an APK
1. Install Android Studio (current stable) on a computer.
2. Open this folder as an existing project.
3. Allow Gradle sync to finish; install Android SDK 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install the generated APK on your Android phone.
6. Open Yalla Typeboard, allow “Display over other apps”, and tap Start floating panel.

## Important limits
- This project is source code, not a prebuilt APK. It must be built in Android Studio.
- It does not hook into, modify, reverse-engineer, or control Yalla Ludo.
- It does not auto-type, auto-drop, or send messages. It only prepares and copies text; the user reviews and pastes it manually.
- Test on your own device. Android manufacturers may apply extra background/overlay restrictions.
