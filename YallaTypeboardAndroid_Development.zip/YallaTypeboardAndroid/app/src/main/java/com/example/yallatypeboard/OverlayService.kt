package com.example.yallatypeboard

import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.graphics.drawable.GradientDrawable
import kotlin.math.max
import kotlin.math.min

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private lateinit var params: WindowManager.LayoutParams
    private val enabled = mutableMapOf("Auto Nums" to false, "Auto Alpha" to false, "Auto Words" to false, "iPhone Drop" to true)
    private lateinit var message: EditText
    private lateinit var count: EditText
    private lateinit var output: EditText
    private lateinit var status: TextView

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!android.provider.Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (panel == null) showPanel()
        return START_NOT_STICKY
    }

    private fun bg(color: Int, radius: Float = 16f) = GradientDrawable().apply { setColor(color); cornerRadius = radius }
    private fun label(text: String, size: Float = 14f) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(Color.WHITE); setPadding(8, 7, 8, 7)
    }
    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; setOnClickListener { action() }
    }

    private fun showPanel() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(12, 10, 12, 12)
            background = bg(Color.argb(244, 19, 27, 41), 22f)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = label("Typeboard", 17f).apply { setTypeface(null, Typeface.BOLD) }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button("×") { stopSelf() })
        root.addView(header)

        listOf("Auto Nums", "Auto Alpha", "Auto Words", "iPhone Drop").forEach { name ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(label(name), LinearLayout.LayoutParams(0, -2, 1f))
            val toggle = button(if (enabled[name] == true) "ON" else "OFF") { }
            fun refresh() { toggle.text = if (enabled[name] == true) "ON" else "OFF" }
            toggle.setOnClickListener { enabled[name] = enabled[name] != true; refresh() }
            row.addView(toggle)
            root.addView(row)
        }
        message = EditText(this).apply { hint = "Your message"; textSize = 13f; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); minLines = 1; maxLines = 3 }
        root.addView(message)
        count = EditText(this).apply { setText("10"); hint = "Count (1–50)"; inputType = android.text.InputType.TYPE_CLASS_NUMBER; textSize = 13f; setTextColor(Color.WHITE) }
        root.addView(count)
        root.addView(button("Prepare text") { prepareText() })
        output = EditText(this).apply { hint = "Prepared text appears here"; textSize = 12f; setTextColor(Color.WHITE); minLines = 2; maxLines = 5; isFocusable = true }
        root.addView(output)
        root.addView(button("Copy prepared text") { copyText() })
        status = label("Review, then paste/send manually.", 11f)
        root.addView(status)

        params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.78f).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 120 }
        header.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=params.x; oy=params.y; return true }
                    MotionEvent.ACTION_MOVE -> { params.x=ox-(e.rawX-sx).toInt(); params.y=oy+(e.rawY-sy).toInt(); wm.updateViewLayout(root, params); return true }
                }; return false
            }
        })
        panel = root
        wm.addView(root, params)
    }

    private fun prepareText() {
        val n = max(1, min(50, count.text.toString().toIntOrNull() ?: 1))
        val msg = message.text.toString().trim()
        val result = when {
            enabled["Auto Nums"] == true -> (1..n).joinToString("\n") { it.toString() }
            enabled["Auto Alpha"] == true -> (0 until n).joinToString("\n") { ('A'.code + it % 26).toChar().toString() }
            enabled["Auto Words"] == true -> if (msg.isEmpty()) "Enter a message first." else List(n) { msg }.joinToString("\n")
            else -> if (msg.isEmpty()) "Enter a message first." else msg
        }
        output.setText(result)
        status.text = "Prepared. Review before copying."
    }

    private fun copyText() {
        val text = output.text.toString()
        if (text.isBlank() || text == "Enter a message first.") { status.text = "Prepare text first."; return }
        val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cb.setPrimaryClip(ClipData.newPlainText("Typeboard text", text))
        status.text = "Copied. Paste manually in your chat."
        Toast.makeText(this, "Text copied", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        panel?.let { view -> try { wm.removeView(view) } catch (_: Exception) {} }; panel = null
        super.onDestroy()
    }
}
