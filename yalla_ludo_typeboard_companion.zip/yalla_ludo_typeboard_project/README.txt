Yalla Ludo Typeboard Companion — demo source

Contents:
- index.html: standalone responsive Typeboard-style companion panel.

How to use:
1. Extract the ZIP.
2. Open index.html in Chrome on Android or a desktop browser.
3. Switch the text preparation options, enter a message if needed, and press Prepare text.
4. Review the result, press Copy, then paste/send manually in the app.

Important:
- This is not an APK and does not install as an Android floating overlay.
- It does not modify Yalla Ludo, inspect its private data, or automate sending.
- A native Android overlay/app would require a separate Android Studio project and testing on your device.
